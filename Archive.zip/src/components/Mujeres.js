const Mujeres = () => {
    return (
        <h2>Modelos de traje de baños de mujeres</h2>
    )
}

export default Mujeres;