const Hombres = () => {
    return (
        <h2>Modelos de traje de baños de hombres</h2>
    )
}

export default Hombres;