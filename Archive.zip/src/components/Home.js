const Home = () => {
    return(
        <h1>Preparate para el verano 🩱👙🩲🩳</h1>
    )
}

export default Home;