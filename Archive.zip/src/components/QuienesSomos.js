 const QuienesSomos = () => {
     return (
         <p>Somos una empresa familiar que se crea hace 10 años.  Nuestra historia comenzo en un garage,
             no estabamos pasando una buena situacion economica y decidimos viajar a Mar del Plata para probar 
             suerte en la temporada , se nos ocurrio unos meses antes, comprar telas y comenzar a hacer mallas. 
             Al principio no creimos tener suerte entonces hicimos poco stock, solo llevamos 5 mallas de mujeres, 
             5 de varones y 2 de niños, si bien ibamos con esperanza pensamos que vamos a un lugar donde abundan
             los negocios de mallas, pero decididos fuimos y vendimos todo. 
             Y asi fue creciendo el negocio , que hoy cuenta con dos locales y siempre siempre mucho amor en el 
             diseño de las prendas
         </p>
     )
 }

 export default QuienesSomos;

 