const Chicos = () => {
    return (
        <h2>Modelos de traje de baños de niños y niñas</h2>
    )
}

export default Chicos;