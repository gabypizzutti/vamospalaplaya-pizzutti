import './App.css';
import Navbar from './components/Navbar';
import CartWidget from './components/CartWidget';
import ItemListContainer from './components/ItemListContainer';
import 'bootstrap/dist/css/bootstrap.min.css';
import ItemDetailContainer from './components/ItemDetailContainer';
import QuienesSomos from './components/QuienesSomos';
import { BrowserRouter, Route } from 'react-router-dom';
import customFetch from './utils/customFetch';
import {useEffect} from 'react';
import Home from './components/Home';
import Mujeres from './components/Mujeres';
import Hombres from './components/Hombres';
import Chicos from './components/Chicos';


function App() {

  useEffect (() => {
    customFetch ()
    .then(result => console.log(result))
    .catch(err => console.log(err))
  }, [])

  return (
   <>
    <Navbar>
      <div className="App">
        <header className="App-header">
        </header>
      </div>
      <CartWidget/>
    </Navbar>
    <ItemListContainer greeting="Este verano es tuyo...🏖"/>
    <ItemDetailContainer/>
    <BrowserRouter>
    <Route path="/Home">
    <Home/>
    </Route>
    <Route path="/QuienesSomos">
    <QuienesSomos/>
    </Route>
    <Route path="/Mujeres">
    <Mujeres/>
    </Route>
    <Route path="/Hombres">
    <Hombres/>
    </Route>
    <Route path="/Chicos">
    <Chicos/>
    </Route>
    </BrowserRouter>
   </>
  );
}

export default App;
